const express = require('express');
const path = require('path');
const app = express();
const indexRoutes = require('./routes/index');

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Set the views directory
app.set('views', path.join(__dirname, 'views'));

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to parse request bodies
app.use(express.urlencoded({ extended: true }));

// Configure routes
app.use('/', indexRoutes);

// Error handling middleware
app.use((req, res, next) => {
    res.status(404).render('404'); // Render a 404 page if no route matches
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});