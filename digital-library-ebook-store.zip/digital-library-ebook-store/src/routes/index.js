const express = require('express');
const router = express.Router();
const LibraryController = require('../controllers/libraryController');

const libraryController = new LibraryController();

// GET routes
router.get('/', libraryController.getHomePage);
router.get('/about', libraryController.getAboutPage);
router.get('/contact', libraryController.getContactPage);
router.get('/cart', libraryController.getCartPage);
router.get('/register', libraryController.getRegistrationPage);
router.get('/login', libraryController.getLoginPage);

// POST routes for form submissions
router.post('/contact', libraryController.postContactPage);
router.post('/register', libraryController.postRegistrationPage);
router.post('/login', libraryController.postLoginPage);

// Cart routes
router.post('/add-to-cart', libraryController.addToCart);
router.post('/remove-from-cart', libraryController.removeFromCart);
router.post('/update-cart', libraryController.updateCart);

module.exports = router;