const mysql = require('mysql2/promise');

// Create a connection pool
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'digital_library_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Test the connection
async function testConnection() {
    try {
        const connection = await pool.getConnection();
        console.log('MySQL connected successfully');
        connection.release();
        return true;
    } catch (error) {
        console.error('MySQL connection failed:', error.message);
        return false;
    }
}

// Initialize database with required tables if they don't exist
async function initDatabase() {
    try {
        const connection = await pool.getConnection();
        
        // Create user_tbl
        await connection.query(`
            CREATE TABLE IF NOT EXISTS user_tbl (
                id INT AUTO_INCREMENT PRIMARY KEY,
                firstName VARCHAR(100) NOT NULL,
                lastName VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                phone VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        
        // Create course_tbl (for books/courses)
        await connection.query(`
            CREATE TABLE IF NOT EXISTS course_tbl (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                author VARCHAR(100) NOT NULL,
                description TEXT,
                price DECIMAL(10, 2) NOT NULL,
                image VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        
        // Create cart_tbl
        await connection.query(`
            CREATE TABLE IF NOT EXISTS cart_tbl (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                course_id INT,
                quantity INT DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES user_tbl(id) ON DELETE CASCADE,
                FOREIGN KEY (course_id) REFERENCES course_tbl(id) ON DELETE CASCADE
            )
        `);
        
        // Create contact_tbl
        await connection.query(`
            CREATE TABLE IF NOT EXISTS contact_tbl (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                subject VARCHAR(255) NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        
        // Insert sample books/courses if the table is empty
        const [rows] = await connection.query('SELECT COUNT(*) as count FROM course_tbl');
        if (rows[0].count === 0) {
            await connection.query(`
                INSERT INTO course_tbl (title, author, description, price, image) VALUES
                ('The Great Gatsby', 'F. Scott Fitzgerald', 'A classic novel about the American Dream', 999, 'https://ia800404.us.archive.org/view_archive.php?archive=/33/items/l_covers_0010/l_covers_0010_52.zip&file=0010521270-L.jpg'),
                ('To Kill a Mockingbird', 'Harper Lee', 'A powerful story of racial injustice', 1199, 'https://ia800404.us.archive.org/view_archive.php?archive=/33/items/l_covers_0010/l_covers_0010_52.zip&file=0010523338-L.jpg'),
                ('1984', 'George Orwell', 'A dystopian novel about totalitarianism', 899, 'https://ia800404.us.archive.org/view_archive.php?archive=/33/items/l_covers_0010/l_covers_0010_59.zip&file=0010594765-L.jpg'),
                ('The Hobbit', 'J.R.R. Tolkien', 'A fantasy novel about a hobbit on an adventure', 1299, 'https://covers.openlibrary.org/b/id/12645114-L.jpg'),
                ('Pride and Prejudice', 'Jane Austen', 'A romantic novel about societal expectations', 799, 'https://covers.openlibrary.org/b/id/12890689-L.jpg'),
                ('The Catcher in the Rye', 'J.D. Salinger', 'A coming-of-age novel about teenage angst', 999, 'https://covers.openlibrary.org/b/id/6297651-L.jpg'),
                ('Harry Potter and the Sorcerer\'s Stone', 'J.K. Rowling', 'The first book in the Harry Potter series', 1499, 'https://covers.openlibrary.org/b/id/12003329-L.jpg')
            `);
        }
        
        connection.release();
        console.log('Database initialized successfully');
        return true;
    } catch (error) {
        console.error('Database initialization failed:', error.message);
        return false;
    }
}

module.exports = {
    pool,
    testConnection,
    initDatabase
};