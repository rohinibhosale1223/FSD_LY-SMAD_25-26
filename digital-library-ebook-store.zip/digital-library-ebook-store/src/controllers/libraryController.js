// In-memory data store
const db = {
    users: [],
    courses: [
        {
            id: 1,
            title: "The Great Gatsby",
            author: "F. Scott Fitzgerald",
            price: 999,
            image: "https://ia800404.us.archive.org/view_archive.php?archive=/33/items/l_covers_0010/l_covers_0010_52.zip&file=0010521270-L.jpg",
            description: "A classic novel about the American Dream"
        },
        {
            id: 2,
            title: "To Kill a Mockingbird",
            author: "Harper Lee",
            price: 1199,
            image: "https://ia800404.us.archive.org/view_archive.php?archive=/33/items/l_covers_0010/l_covers_0010_52.zip&file=0010523338-L.jpg",
            description: "A powerful story of racial injustice"
        },
        {
            id: 3,
            title: "1984",
            author: "George Orwell",
            price: 899,
            image: "https://ia800404.us.archive.org/view_archive.php?archive=/33/items/l_covers_0010/l_covers_0010_59.zip&file=0010594765-L.jpg",
            description: "A dystopian novel about totalitarianism"
        },
        {
            id: 4,
            title: "The Hobbit",
            author: "J.R.R. Tolkien",
            price: 1299,
            image: "https://covers.openlibrary.org/b/id/12645114-L.jpg",
            description: "A fantasy novel about a hobbit on an adventure"
        },
        {
            id: 5,
            title: "Pride and Prejudice",
            author: "Jane Austen",
            price: 799,
            image: "https://covers.openlibrary.org/b/id/12890689-L.jpg",
            description: "A romantic novel about societal expectations"
        },
        {
            id: 6,
            title: "The Catcher in the Rye",
            author: "J.D. Salinger",
            price: 999,
            image: "https://covers.openlibrary.org/b/id/6297651-L.jpg",
            description: "A coming-of-age novel about teenage angst"
        },
        {
            id: 7,
            title: "Harry Potter and the Sorcerer's Stone",
            author: "J.K. Rowling",
            price: 1499,
            image: "https://covers.openlibrary.org/b/id/12003329-L.jpg",
            description: "The first book in the Harry Potter series"
        }
    ],
    contacts: [],
    cart: [
        { id: 1, title: 'The Great Gatsby', price: 999, quantity: 1 },
        { id: 2, title: 'To Kill a Mockingbird', price: 1199, quantity: 1 }
    ]
};

class LibraryController {
    getHomePage(req, res) {
        res.render('index', { 
            featuredBooks: db.courses,
            pageTitle: 'Home - Digital Library & E-Book Store',
            successMessage: req.query.success || '',
            errorMessage: req.query.error || ''
        });
    }
    
    // Add to cart functionality
    addToCart(req, res) {
        const { bookId } = req.body;
        const bookIdNum = parseInt(bookId);
        
        // Find the book in our courses
        const book = db.courses.find(book => book.id === bookIdNum);
        
        if (!book) {
            return res.redirect('/?error=Book not found');
        }
        
        // Check if book is already in cart
        const existingCartItem = db.cart.find(item => item.id === bookIdNum);
        
        if (existingCartItem) {
            // Increment quantity if already in cart
            existingCartItem.quantity += 1;
        } else {
            // Add new item to cart
            db.cart.push({
                id: book.id,
                title: book.title,
                price: book.price,
                quantity: 1
            });
        }
        
        return res.redirect('/?success=Book added to cart successfully');
    }
    
    // Remove from cart functionality
    removeFromCart(req, res) {
        const { itemId } = req.body;
        const itemIdNum = parseInt(itemId);
        
        // Find the item index
        const itemIndex = db.cart.findIndex(item => item.id === itemIdNum);
        
        if (itemIndex !== -1) {
            // Remove the item
            db.cart.splice(itemIndex, 1);
            return res.redirect('/cart?success=Item removed from cart');
        }
        
        return res.redirect('/cart?error=Item not found in cart');
    }
    
    // Update cart quantity
    updateCart(req, res) {
        const { itemId, quantity } = req.body;
        const itemIdNum = parseInt(itemId);
        const quantityNum = parseInt(quantity);
        
        // Validate quantity
        if (isNaN(quantityNum) || quantityNum < 1 || quantityNum > 10) {
            return res.redirect('/cart?error=Invalid quantity');
        }
        
        // Find the item
        const item = db.cart.find(item => item.id === itemIdNum);
        
        if (item) {
            // Update quantity
            item.quantity = quantityNum;
            return res.redirect('/cart?success=Cart updated');
        }
        
        return res.redirect('/cart?error=Item not found in cart');
    }

    getAboutPage(req, res) {
        res.render('about');
    }

    getContactPage(req, res) {
        res.render('contact', { successMessage: '', errorMessage: '' });
    }

    // Handle contact form submission - CREATE operation
    postContactPage(req, res) {
        const { name, email, subject, message } = req.body;
        
        // Save to in-memory database
        const newContact = {
            id: db.contacts.length + 1,
            name,
            email,
            subject,
            message,
            created_at: new Date()
        };
        
        db.contacts.push(newContact);
        
        res.render('contact', { 
            successMessage: 'Thank you for your message! We will get back to you soon.',
            errorMessage: '' 
        });
    }

    getCartPage(req, res) {
        // READ operation - get cart items
        const cartItems = db.cart;
        
        // Add book details to cart items
        const enhancedCartItems = cartItems.map(item => {
            const book = db.courses.find(book => book.id === item.id);
            return {
                ...item,
                image: book ? book.image : '',
                author: book ? book.author : 'Unknown'
            };
        });
        
        const subtotal = enhancedCartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
        const tax = Math.round(subtotal * 0.05); // 5% tax
        const total = subtotal + tax;
        
        res.render('cart', { 
            cartItems: enhancedCartItems, 
            subtotal, 
            tax, 
            total,
            successMessage: req.query.success || '',
            errorMessage: req.query.error || ''
        });
    }

    getRegistrationPage(req, res) {
        res.render('register', { successMessage: '', errorMessage: '' });
    }

    // Handle registration form submission - CREATE operation
    postRegistrationPage(req, res) {
        const { firstName, lastName, email, password, confirmPassword, phone, terms } = req.body;
        
        // Basic validation
        if (password !== confirmPassword) {
            return res.render('register', { 
                errorMessage: 'Passwords do not match.',
                successMessage: '' 
            });
        }
        
        if (!terms) {
            return res.render('register', { 
                errorMessage: 'You must agree to the terms and conditions.',
                successMessage: '' 
            });
        }
        
        // Check if email already exists
        const existingUser = db.users.find(user => user.email === email);
        if (existingUser) {
            return res.render('register', { 
                errorMessage: 'Email already in use. Please use a different email or login.',
                successMessage: '' 
            });
        }
        
        // Save to in-memory database
        const newUser = {
            id: db.users.length + 1,
            firstName,
            lastName,
            email,
            password,
            phone,
            created_at: new Date()
        };
        
        db.users.push(newUser);
        
        res.render('register', { 
            successMessage: 'Account created successfully! You can now log in.',
            errorMessage: '' 
        });
    }

    getLoginPage(req, res) {
        res.render('login', { successMessage: '', errorMessage: '' });
    }

    // Handle login form submission - READ operation
    postLoginPage(req, res) {
        const { email, password, rememberMe } = req.body;
        
        // Validate against in-memory database
        const user = db.users.find(user => user.email === email && user.password === password);
        
        if (user) {
            // In a real app, you would set up a session here
            res.render('login', { 
                successMessage: 'Login successful! Welcome back.',
                errorMessage: '' 
            });
        } else {
            res.render('login', { 
                errorMessage: 'Invalid email or password.',
                successMessage: '' 
            });
        }
    }
}

module.exports = LibraryController;