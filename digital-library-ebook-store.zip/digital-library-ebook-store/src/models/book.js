class Book {
    constructor(title, author, genre, price) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.price = price;
    }

    // Method to save the book to the database
    save() {
        // Logic to save the book to the database
    }

    // Method to find a book by title
    static findByTitle(title) {
        // Logic to find a book by title in the database
    }

    // Method to get all books
    static getAllBooks() {
        // Logic to retrieve all books from the database
    }
}

module.exports = Book;